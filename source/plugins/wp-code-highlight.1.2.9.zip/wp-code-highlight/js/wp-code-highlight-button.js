/**
* @plugin name WP Code Highlight
* @plugin url http://boliquan.com/wp-code-highlight/
*/
edButtons[edButtons.length] = new edButton( 'pre', 'WP-Code-Highlight', '<pre>\n', '\n</pre>\n', 'p' );
